<a href="/" >
    <img style="margin: auto;" src="{{ url('assets/dict-logo.png') }}" alt="" width="10%">
</a>
