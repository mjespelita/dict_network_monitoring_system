<a href="/" >
    <img style="margin: auto;" src="<?php echo e(url('assets/dict-logo.png')); ?>" alt="" width="10%">
</a>
<?php /**PATH C:\Users\USER\_web\omada_clone\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>