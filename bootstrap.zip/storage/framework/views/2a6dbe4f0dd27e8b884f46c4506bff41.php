<?php echo e($slot); ?>

<?php /**PATH C:\Users\USER\_web\omada_clone\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>