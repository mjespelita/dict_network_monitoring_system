<?php $__env->startSection('content'); ?>
    <h1>Notes Details</h1>
    <div class="card">
        <div class="card-body">
            <div class='table-responsive'>
                <table class='table'>
                    <tr>
                        <th>ID</th>
                        <td><?php echo e($item->id); ?></td>
                    </tr>
                    
                <tr>
                    <th>Name</th>
                    <td><?php echo e($item->name); ?></td>
                </tr>
            
                <tr>
                    <th>Content</th>
                    <td><?php echo e($item->content); ?></td>
                </tr>
            
                <tr>
                    <th>Status</th>
                    <td><?php echo e($item->status); ?></td>
                </tr>
            
                </table>
            </div>
        </div>
    </div>

    <a href='<?php echo e(route('notes.index')); ?>' class='btn btn-primary'>Back to List</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mark Jason Espelita\_web\laramark\resources\views/notes/show-notes.blade.php ENDPATH**/ ?>