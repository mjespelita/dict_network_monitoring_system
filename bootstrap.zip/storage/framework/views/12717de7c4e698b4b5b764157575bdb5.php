<a href="/">
    <img src="<?php echo e(url('assets/librify-logo.png')); ?>" alt="" width="90%">
</a>
<?php /**PATH C:\Users\Mark Jason Espelita\_web\Omada Clone\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>