<?php $__env->startSection('content'); ?>

    <h1>Ticket Logs</h1>

    <div class='card'>
        <div class='card-body'>

            <div class="list-group">
                <?php $__empty_1 = true; $__currentLoopData = $audits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="list-group-item mb-2">
                        <p class="mb-1">
                            <strong><?php echo e($audit->user ? $audit->user->name : 'System'); ?></strong>
                            <?php echo e($audit->event); ?>

                            <strong><?php echo e(class_basename($audit->auditable_type)); ?> #<?php echo e($audit->auditable_id); ?></strong>
                            on <?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($audit->created_at)); ?>

                        </p>

                        <?php
                            $pairs = explode(',', $audit->tags);
                            $tagsArray = [];
                            foreach ($pairs as $pair) {
                                $parts = explode(':', $pair, 2);
                                if(count($parts) == 2) {
                                    $tagsArray[$parts[0]] = $parts[1];
                                }
                            }
                        ?>

                        

                        <pre><?php echo e($audit->tags); ?></pre>

                        <a href="<?php echo e(url('/show-sites/'.$tagsArray['sites_id'] ?? 'Not Found')); ?>">
                            <button class="btn btn-success">View Details</button>
                        </a>

                        <?php if($audit->event === 'updated'): ?>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered mb-2">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Field</th>
                                            <th>Old Value</th>
                                            <th>New Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $audit->new_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $old = $audit->old_values[$key] ?? 'N/A';
                                            ?>
                                            <tr>
                                                <td><?php echo e(ucfirst($key)); ?></td>
                                                <td class="text-danger"><?php echo e($old); ?></td>
                                                <td class="text-success"><?php echo e($value); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php elseif($audit->event === 'created'): ?>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered mb-2">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Field</th>
                                            <th>New Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $audit->new_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(ucfirst($key)); ?></td>
                                                <td class="text-success"><?php echo e($value); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php elseif($audit->event === 'deleted'): ?>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered mb-2">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Field</th>
                                            <th>Deleted Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $audit->old_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(ucfirst($key)); ?></td>
                                                <td class="text-danger"><?php echo e($value); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>


                        <small class="text-muted">
                            IP: <?php echo e($audit->ip_address); ?> | URL: <?php echo e($audit->url); ?> | Agent: <?php echo e(Str::limit($audit->user_agent, 40)); ?>

                        </small>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-center text-muted">No audit logs available.</p>
                <?php endif; ?>
            </div>

            <div class="mt-4">
                <?php echo e($audits->links('pagination::bootstrap-5')); ?>

            </div>

        </div>
    </div>

    <a href='<?php echo e(route('sites.index')); ?>' class='btn btn-primary'>Back to List</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\_web\omada_clone\resources\views/sample-frontend/ticket-audits.blade.php ENDPATH**/ ?>