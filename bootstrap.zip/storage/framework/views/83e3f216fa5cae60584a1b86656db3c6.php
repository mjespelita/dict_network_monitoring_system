
<!DOCTYPE html>
<html lang='<?php echo e(str_replace('_', '-', app()->getLocale())); ?>'>
    <head>
        <meta charset='utf-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1'>
        <meta name='csrf-token' content='<?php echo e(csrf_token()); ?>'>
        <meta name='author' content='Mark Jason Penote Espelita'>
        <meta name='keywords' content='keyword1, keyword2'>
        <meta name='description' content='Dolorem natus ab illum beatae error voluptatem incidunt quis. Cupiditate ullam doloremque delectus culpa. Autem harum dolorem praesentium dolorum necessitatibus iure quo. Et ea aut voluptatem expedita.'>

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <link href='<?php echo e(url('assets/bootstrap/bootstrap.min.css')); ?>' rel='stylesheet'>
        <!-- FontAwesome for icons -->
        <link href='<?php echo e(url('assets/font-awesome/css/all.min.css')); ?>' rel='stylesheet'>
        <link rel='stylesheet' href='<?php echo e(url('assets/custom/style.css')); ?>'>
        <link rel='icon' href='<?php echo e(url('assets/logo.png')); ?>'>
    </head>
    <body class='font-sans antialiased'>

        <!-- Sidebar for Desktop View -->
        <div class='sidebar' id='mobileSidebar'>
            <div class='logo'>
                <img src='<?php echo e(url('assets/logo.png')); ?>' alt='' width='100%'>
            </div>
            <a href='<?php echo e(url('dashboard')); ?>' class='<?php echo e(request()->is('dashboard') ? 'active' : ''); ?>'><i class='fas fa-tachometer-alt'></i> Dashboard</a>
            <a href='<?php echo e(url('logs')); ?>' class='<?php echo e(request()->is('logs', 'create-logs', 'show-logs/*', 'edit-logs/*', 'delete-logs/*', 'logs-search*') ? 'active' : ''); ?>'><i class='fas fa-bars'></i> Logs</a>
            <a href='<?php echo e(url('tasks')); ?>' class='<?php echo e(request()->is('tasks', 'create-tasks', 'trash-tasks', 'show-tasks/*', 'edit-tasks/*', 'delete-tasks/*', 'tasks-search*') ? 'active' : ''); ?>'><i class='fas fa-bars'></i> Tasks</a>
            <a href='<?php echo e(url('notes')); ?>' class='<?php echo e(request()->is('notes', 'create-notes', 'trash-notes', 'show-notes/*', 'edit-notes/*', 'delete-notes/*', 'notes-search*') ? 'active' : ''); ?>'><i class='fas fa-bars'></i> Notes</a>
            <a href='<?php echo e(url('books')); ?>' class='<?php echo e(request()->is('books', 'create-books', 'trash-books', 'show-books/*', 'edit-books/*', 'delete-books/*', 'books-search*') ? 'active' : ''); ?>'><i class='fas fa-bars'></i> Books</a>
            <a href='<?php echo e(url('user/profile')); ?>'><i class='fas fa-user'></i> <?php echo e(Auth::user()->name); ?></a>
        </div>

        <!-- Top Navbar -->
        <nav class='navbar navbar-expand-lg navbar-dark'>
            <div class='container-fluid'>
                <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbarNav'
                    aria-controls='navbarNav' aria-expanded='false' aria-label='Toggle navigation' onclick='toggleSidebar()'>
                    <i class='fas fa-bars'></i>
                </button>
            </div>
        </nav>

        <?php if (isset($component)) { $__componentOriginalf51e58d5cce915072d5188ae79588f9f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf51e58d5cce915072d5188ae79588f9f = $attributes; } ?>
<?php $component = App\View\Components\MainNotification::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-notification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainNotification::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf51e58d5cce915072d5188ae79588f9f)): ?>
<?php $attributes = $__attributesOriginalf51e58d5cce915072d5188ae79588f9f; ?>
<?php unset($__attributesOriginalf51e58d5cce915072d5188ae79588f9f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf51e58d5cce915072d5188ae79588f9f)): ?>
<?php $component = $__componentOriginalf51e58d5cce915072d5188ae79588f9f; ?>
<?php unset($__componentOriginalf51e58d5cce915072d5188ae79588f9f); ?>
<?php endif; ?>

        <div class='content'>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <!-- Bootstrap JS and dependencies -->
        <script src='<?php echo e(url('assets/bootstrap/bootstrap.bundle.min.js')); ?>'></script>

        <!-- Custom JavaScript -->
        <script src="<?php echo e(url('assets/custom/script.js')); ?>"></script>
        <script>
            function toggleSidebar() {
                document.getElementById('mobileSidebar').classList.toggle('active');
                document.getElementById('sidebar').classList.toggle('active');
            }
        </script>
    </body>
</html>
<?php /**PATH C:\Users\Mark Jason Espelita\_web\laramark\resources\views/layouts/main.blade.php ENDPATH**/ ?>