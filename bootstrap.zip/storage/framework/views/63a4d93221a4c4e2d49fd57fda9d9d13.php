<?php $__env->startSection('content'); ?>
    <h1>Dashboard</h1>
    <b>Hello, <?php echo e(Auth::user()->name); ?> (<?php echo e(Auth::user()->role); ?>)</b>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Total Sites</h5>
                    <h1>
                        <i class="fas fa-house"></i> 322
                    </h1>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\_web\omada_clone\resources\views/admin-dashboard.blade.php ENDPATH**/ ?>