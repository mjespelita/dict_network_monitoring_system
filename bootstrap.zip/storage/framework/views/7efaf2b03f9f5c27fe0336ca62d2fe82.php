<?php $__env->startSection('content'); ?>
    <h1>Create a new uploads</h1>

    <div class='card'>
        <div class='card-body'>
            <form action='<?php echo e(route('uploads.store')); ?>' method='POST' enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                
        <div class='form-group my-4'>
            <label for='name'>Customers</label>
            <input type='file' class='form-control' id='file' name='customers' required>
        </div>

        <div class='form-group my-4'>
            <label for='name'>Sites</label>
            <input type='file' class='form-control' id='file' name='sites' required>
        </div>
    
                <button type='submit' class='btn btn-primary mt-3'>Create</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mark Jason Espelita\_web\Omada Clone\resources\views/uploads/create-uploads.blade.php ENDPATH**/ ?>