<?php $__env->startSection('content'); ?>
    <h1>Create New User Account</h1>

    <div class='card'>
        <div class='card-body'>
            <form action='<?php echo e(route('useraccounts.store')); ?>' method='POST'>
                <?php echo csrf_field(); ?>

        <div class='form-group'>
            <label for='name'>Name</label>
            <input type='text' class='form-control' id='name' name='name' required>
        </div>

        <div class='form-group'>
            <label for='name'>Email</label>
            <input type='text' class='form-control' id='email' name='email' required>
        </div>

        <div class='form-group'>
            <label for='name'>Password</label>
            <input type='password' class='form-control' id='password' name='password' required>
        </div>

        <div class='form-group'>
            <label for='name'>Role</label>
            <select name="role" class="form-control" id="" required>
                <option value="admin">Admin</option>
                <option value="admin">User</option>
                <option value="dict">DICT RO8 Representative</option>
            </select>
            
        </div>

                <button type='submit' class='btn btn-primary mt-3'>Create</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\_web\omada_clone\resources\views/useraccounts/create-useraccounts.blade.php ENDPATH**/ ?>