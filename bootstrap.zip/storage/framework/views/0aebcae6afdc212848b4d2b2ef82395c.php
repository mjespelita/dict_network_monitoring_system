<?php $__env->startSection('content'); ?>
    <h1><?php echo e($item->name); ?></h1>

    <?php if (isset($component)) { $__componentOriginal7103936932119d002d785465378b191d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7103936932119d002d785465378b191d = $attributes; } ?>
<?php $component = App\View\Components\InternalSidebar::resolve(['item' => $item] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('internal-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\InternalSidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7103936932119d002d785465378b191d)): ?>
<?php $attributes = $__attributesOriginal7103936932119d002d785465378b191d; ?>
<?php unset($__attributesOriginal7103936932119d002d785465378b191d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7103936932119d002d785465378b191d)): ?>
<?php $component = $__componentOriginal7103936932119d002d785465378b191d; ?>
<?php unset($__componentOriginal7103936932119d002d785465378b191d); ?>
<?php endif; ?>

    <div class="card">
        <div class="card-body">

            

            <style>
                @keyframes spin {
                    to { transform: rotate(360deg); }
                }
                </style>

            <div>
                <div class="row" id="overviewDiagramSummary">
                    <div class="loadingPlaceholder" style="width: 100%; text-align: center; padding: 50px 0;">
                        <div style="display: inline-block; width: 3rem; height: 3rem; border: 0.4rem solid #ccc; border-top-color: #007bff; border-radius: 50%; animation: spin 1s linear infinite;"></div>
                        <div style="margin-top: 1rem; color: #888;">Loading overview diagram...</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class='card'>
        <div class='card-body'>

            <div class='table-responsive'>
                <table class='table'>

                <tr>
                    <th>Name</th>
                    <td><?php echo e($item->name); ?></td>
                </tr>

                <tr>
                    <th>Site Id</th>
                    <td><?php echo e($item->siteId); ?></td>
                </tr>

                <tr>
                    <th>Region</th>
                    <td><?php echo e($item->region); ?></td>
                </tr>

                <tr>
                    <th>Timezone</th>
                    <td><?php echo e($item->timezone); ?></td>
                </tr>

                <tr>
                    <th>Scenario</th>
                    <td><?php echo e($item->scenario); ?></td>
                </tr>

                <tr>
                    <th>Type</th>
                    <td><?php echo e($item->type); ?></td>
                </tr>

                    <tr>
                        <th>Created At</th>
                        <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->created_at)); ?></td>
                    </tr>
                    <tr>
                        <th>Updated At</th>
                        <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->updated_at)); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <a href='<?php echo e(route('sites.index')); ?>' class='btn btn-primary'>Back to List</a>

    <script>
        const siteId = window.location.pathname.split('/').filter(Boolean).pop();
        fetch(`/overview-diagram-api/${siteId}`)
            .then(res => res.json())
            .then(res => {
                const stat = res.result;
                const statCards = `
                    <div class="col-md-3 mb-3"><div class="card p-3"><strong>Total Clients:</strong> <h1>${stat.totalClientNum}</h1></div></div>
                    <div class="col-md-3 mb-3"><div class="card p-3"><strong>Wired Clients:</strong> <h1>${stat.wiredClientNum}</h1></div></div>
                    <div class="col-md-3 mb-3"><div class="card p-3"><strong>Wireless Clients:</strong> <h1>${stat.wirelessClientNum}</h1></div></div>
                    <div class="col-md-3 mb-3"><div class="card p-3"><strong>Guest Clients:</strong> <h1>${stat.guestNum}</h1></div></div>

                    <div class="col-md-3 mb-3"><div class="card p-3"><strong>Total APs:</strong> <h1>${stat.totalApNum}</h1></div></div>
                    <div class="col-md-3 mb-3"><div class="card p-3"><strong>Connected APs:</strong> <h1>${stat.connectedApNum}</h1></div></div>
                    <div class="col-md-3 mb-3"><div class="card p-3"><strong>Disconnected APs:</strong> <h1>${stat.disconnectedApNum}</h1></div></div>

                    <div class="col-md-3 mb-3"><div class="card p-3"><strong>Total Switches:</strong> <h1>${stat.totalSwitchNum}</h1></div></div>
                    <div class="col-md-3 mb-3"><div class="card p-3"><strong>Connected Switches:</strong> <h1>${stat.connectedSwitchNum}</h1></div></div>

                    <div class="col-md-3 mb-3"><div class="card p-3"><strong>Total Ports:</strong> <h1>${stat.totalPorts}</h1></div></div>
                    <div class="col-md-3 mb-3"><div class="card p-3"><strong>Available Ports:</strong> <h1>${stat.availablePorts}</h1></div></div>

                    <div class="col-md-3 mb-3"><div class="card p-3"><strong>Power Consumption:</strong> <h1>${stat.powerConsumption} W</h1></div></div>
                `;

                const container = document.getElementById("overviewDiagramSummary");
                container.innerHTML = statCards;
            })
            .catch(err => {
                $.get('/generate-new-api-token', function (res) {
                    window.location.reload();
                })
                console.error("Error loading overview diagram:", err);
                document.getElementById("overviewDiagramSummary").innerHTML = `<div class="text-danger">Failed to load data.</div>`;
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\_web\omada_clone\resources\views/sites/show-sites.blade.php ENDPATH**/ ?>