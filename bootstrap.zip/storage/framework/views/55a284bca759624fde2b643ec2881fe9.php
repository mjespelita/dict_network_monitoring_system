<a href="/">
    <img src="<?php echo e(url('assets/logo.png')); ?>" alt="" width="100px">
</a>
<?php /**PATH C:\Users\Mark Jason Espelita\_web\laramark\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>