<?php $__env->startSection('content'); ?>
    <h1>Customers Details</h1>

    <div class='card'>
        <div class='card-body'>
            <div class='table-responsive'>
                <table class='table'>
                    <tr>
                        <th>ID</th>
                        <td><?php echo e($item->id); ?></td>
                    </tr>
                    
        <tr>
            <th>CustomerId</th>
            <td><?php echo e($item->customerId); ?></td>
        </tr>
    
        <tr>
            <th>Name</th>
            <td><?php echo e($item->name); ?></td>
        </tr>
    
        <tr>
            <th>Description</th>
            <td><?php echo e(empty($item->description) ? "no description" : $item->description); ?></td>
        </tr>
    
          
    
                    <tr>
                        <th>Created At</th>
                        <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->created_at)); ?></td>
                    </tr>
                    <tr>
                        <th>Updated At</th>
                        <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->updated_at)); ?></td>
                    </tr>
                </table>
            </div>


        </div>
    </div>

    <a href='<?php echo e(route('customers.index')); ?>' class='btn btn-primary'>Back to List</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mark Jason Espelita\_web\Omada Clone\resources\views/customers/show-customers.blade.php ENDPATH**/ ?>