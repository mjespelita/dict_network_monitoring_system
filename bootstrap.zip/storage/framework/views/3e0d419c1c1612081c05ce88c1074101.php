<?php $__env->startSection('content'); ?>
    <h1>Auditlogs Details</h1>

    <div class='card'>
        <div class='card-body'>
            <div class='table-responsive'>
                <table class='table'>
                    <tr>
                        <th>ID</th>
                        <td><?php echo e($item->id); ?></td>
                    </tr>
                    
        <tr>
            <th>Time</th>
            <td><?php echo e($item->time); ?></td>
        </tr>
    
        <tr>
            <th>Operator</th>
            <td><?php echo e($item->operator); ?></td>
        </tr>
    
        <tr>
            <th>Resource</th>
            <td><?php echo e($item->resource); ?></td>
        </tr>
    
        <tr>
            <th>Ip</th>
            <td><?php echo e($item->ip); ?></td>
        </tr>
    
        <tr>
            <th>AuditType</th>
            <td><?php echo e($item->auditType); ?></td>
        </tr>
    
        <tr>
            <th>Level</th>
            <td><?php echo e($item->level); ?></td>
        </tr>
    
        <tr>
            <th>Result</th>
            <td><?php echo e($item->result); ?></td>
        </tr>
    
        <tr>
            <th>Content</th>
            <td><?php echo e($item->content); ?></td>
        </tr>
    
        <tr>
            <th>Label</th>
            <td><?php echo e($item->label); ?></td>
        </tr>
    
        <tr>
            <th>OldValue</th>
            <td><?php echo e($item->oldValue); ?></td>
        </tr>
    
        <tr>
            <th>NewValue</th>
            <td><?php echo e($item->newValue); ?></td>
        </tr>
    
                    <tr>
                        <th>Created At</th>
                        <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->created_at)); ?></td>
                    </tr>
                    <tr>
                        <th>Updated At</th>
                        <td><?php echo e(Smark\Smark\Dater::humanReadableDateWithDayAndTime($item->updated_at)); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <a href='<?php echo e(route('auditlogs.index')); ?>' class='btn btn-primary'>Back to List</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mark Jason Espelita\_web\Omada Clone\resources\views/auditlogs/show-auditlogs.blade.php ENDPATH**/ ?>