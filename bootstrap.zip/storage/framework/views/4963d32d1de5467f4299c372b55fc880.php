<?php echo e($slot); ?>

<?php /**PATH C:\Users\Mark Jason Espelita\_web\Omada Clone\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>